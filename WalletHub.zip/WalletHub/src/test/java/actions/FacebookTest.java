package actions;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import pages.*;


import java.io.IOException;

//Facebook Action Class (Assignment 1)
public class FacebookTest {
	private static WebDriver driver = null;
	URL baseUrl = new URL();

	@BeforeTest
	public void startUp() throws IOException {
		//This function calls the Start Browser function inorder for us to initiate the browser we set
		StartBrowser openConnection = new StartBrowser(driver);

		driver = openConnection.initializeBrowser();
	}

	@Test(priority = 1)//Test to Login to facebook with validate username and password
	public void faceBookLogin() throws InterruptedException, IOException {
		String username = "jamesswagz24@gmail.com"; //Username Login used
		String password = "WalletHub123"; //Password Login used

		NavigateToURL startWebsite = new NavigateToURL(driver);
		startWebsite.faceBookUrl(); //Launch Facebook URL

		FacebookPageObject facebookObject = new FacebookPageObject(driver); //Creating an instance FacebookPageObject Class inorder to use the functions
		facebookObject.enterUsername(username);
		facebookObject.enterPassword(password);
		facebookObject.clickLoginButton();
		facebookObject.loggedIn();

	}

	@Test(priority = 2, dependsOnMethods= "faceBookLogin")//this test will depend on priority 1 because of login
	//Function to Post Hello World Status
	public void postStatus() throws InterruptedException, IOException {
		String post = "Hello World";
		FacebookPageObject facebookObject = new FacebookPageObject(driver);

		Thread.sleep(3000);//honestly I put this here so that there can be a slight delay for the next test :)
		facebookObject.clickHomePage();
		facebookObject.clickStatusButton();
		facebookObject.postPopUpDisplayed();
		facebookObject.enterStatus(post);
		facebookObject.clickPost();

	}

		@AfterTest
//Closes down the Browser
	public void TearDown() {
		driver.close();
		driver.quit();
	}

}






