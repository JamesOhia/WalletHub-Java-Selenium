package actions;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import pages.*;

import java.io.IOException;

//Wallet Hub Action Class (Assignment 2)
public class WallethubTest {
	private static WebDriver driver = null;
	private static final String reviewText = "Text from James Ohia (Senior Automation Quality Assurance Engineer). WalletHub is a personal finance website that was launched in August 2013. It is based in Miami and owned by Evolution Finance, Inc. WalletHub offers free consumer tools, such as its WalletLiteracy Quiz and its Financial Fitness Tool, which provides users with credit reports, scores, and monitoring";
	URL baseUrl = new URL();

	@BeforeTest
	public void startUp() throws IOException {
		//This function calls the Start Browser function inorder for us to initiate the browser we set
		StartBrowser openConnection = new StartBrowser(driver);

		driver = openConnection.initializeBrowser();
	}

	@Test(priority = 1)//Test to see if you can post reviews on Wallethub
	public void walletHubPostReview() throws InterruptedException, IOException {

		NavigateToURL startWebsite = new NavigateToURL(driver);
		startWebsite.walletHubUrl(); //Launch Facebook URL

		WallethubPageObject wallethubObject = new WallethubPageObject(driver);

		wallethubObject.ScrollDown();//to scroll down the page
		wallethubObject.hoverStar();
		Thread.sleep(3000);
		wallethubObject.clickStar();
		Thread.sleep(3000);
		wallethubObject.clickPolicyDropdown();
		wallethubObject.selectHealthInsurance();
		wallethubObject.enterReview(reviewText);
		wallethubObject.clickSubmit();
	}

	@Test(priority = 2, dependsOnMethods= "walletHubPostReview")//this test will depend on priority 1 walletHubPostReview
	//Test to see if you can login to your profile and confirm the review posted
	public void loginToSeeReview() throws InterruptedException, IOException {
		String email = "jamesohia4@gmail.com";
		String password = "James1997.";
		WallethubPageObject wallethubObject = new WallethubPageObject(driver); //Creating an instance Wallet Hub Class inorder to use the functions
		Thread.sleep(3000);//To ensure the page is appropriately waited for
		wallethubObject.profileLoginDisplayed();
		wallethubObject.clickProfileTab();
		wallethubObject.enterProfileEmail(email);
		wallethubObject.enterProfilePassword(password);
		wallethubObject.clickLoginButton();
		Thread.sleep(3000);//To ensure the page is appropriately waited for
		wallethubObject.reviewDisplayed();

	}

		@AfterTest
//Closes down the Browser
	public void TearDown() {
		driver.close();
		driver.quit();
	}

}






