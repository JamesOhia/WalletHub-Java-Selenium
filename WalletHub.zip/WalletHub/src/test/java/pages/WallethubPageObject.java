package pages;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.interactions.Actions;

//Class used to store Wallet hub WebElement and create respective click functions. Here we are making use of Page Object Model
//for Object Repository.
public class WallethubPageObject {

	//The Web Element variables are below with their respective locators for searching elements such as id, name and xpath
	private By reviewStar = By.xpath("//*[(local-name()='svg') and (@aria-label='4 star rating') and (@aria-hidden='false')]");
	private By policyDropDown = By.xpath("//div[@class= 'dropdown second']");
	private By healthInsurance = By.xpath("//li[contains(text(), 'Health Insurance')]");
	private By reviewText = By.xpath("//textarea[@class= 'textarea wrev-user-input validate']");
	private By submitButton = By.xpath("//div[(contains(text(), 'Submit'))]");
	private By profilePage = By.xpath("//h1[contains(text(),'Login or sign up so we can post your review.')]");
	private By loginTab = By.xpath("//a[contains(text(),'Login')]");
	private By emailField = By.xpath("//input[(@placeholder='Email Address')]");
	private By passwordField = By.xpath("//input[(@placeholder='Password')]");
	private By loginButton = By.xpath("//button[(@type='button')]");
	private By myReview = By.xpath("//span[(contains(text(), 'Your Review'))]");






	private WebDriver driver;
	private WebDriverWait wait;
	private Actions actions;

	public WallethubPageObject(WebDriver driver) {
		this.driver = driver;
		wait = new WebDriverWait(this.driver, 15); //Explicit WebDriverWait setup
		actions = new Actions(driver); //Interaction.Action class setup to perform hover action
	}

	//Function to Scroll down the page
	public void ScrollDown(){
		JavascriptExecutor js = (JavascriptExecutor) driver;//Launches the javascriptexecutor
		js.executeScript("window.scrollBy(0, 200)");
		System.out.println("Scrolled Page Down");
	}

	//Function to Hover on the 4th Star
	public void hoverStar() {

		try{
			WebElement reviewStars = wait.until(ExpectedConditions.visibilityOfElementLocated(reviewStar));
			actions.moveToElement(reviewStars).perform();
			System.out.println("The Mouse hover on the 4th review star");


		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	//Function to click on the 4th Star
	public void clickStar() {

		try{
			driver.findElement(reviewStar).click();
			System.out.println("The 4th Star was clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	//Function to click on the Policy Drop Down
	public void clickPolicyDropdown() {

		try{
			WebElement dropDown = wait.until(ExpectedConditions.visibilityOfElementLocated(policyDropDown));
			dropDown.click();
			System.out.println("Policy Drop down button was clicked");


		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	//Function to Select Health Insurance from the Dropdown
	public void selectHealthInsurance() {

		try{
			WebElement insurance = wait.until(ExpectedConditions.visibilityOfElementLocated(healthInsurance));
			insurance.click();
			System.out.println("Health Insurance was Selected");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	//Function to Enter Review in the text field
	public void enterReview(String text) {

		try{
			driver.findElement(reviewText).click();
			driver.findElement(reviewText).sendKeys(text);

			System.out.println("Review has been successfully inputted");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	//Function to Submit Review
	public void clickSubmit() {

		try{
			driver.findElement(submitButton).click();
			System.out.println("Review submit button has been clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	//Function to confirm the review confirmation screen is displayed
	public void profileLoginDisplayed() {

		try{
			WebElement profile = wait.until(ExpectedConditions.visibilityOfElementLocated(profilePage));
			if(profile.isDisplayed()){
				System.out.println("Profile Page is displayed");
			}
			else{
				System.out.println("Profile Page didn't display");
			}

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	//Function to Click Continue to go to the profile page
	public void clickProfileTab() {

		try{
			driver.findElement(loginTab).click();
			System.out.println("Profile Login Tab has been clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void enterProfileEmail(String text) {

		try{
			driver.findElement(emailField).sendKeys(text);
			System.out.println("Email Address has been entered into the Profile Email Text Field");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void enterProfilePassword(String text) {

		try{
			driver.findElement(passwordField).sendKeys(text);
			System.out.println("Password has been entered into the Profile Email Text Field");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	public void clickLoginButton() {

		try{
			driver.findElement(loginButton).click();
			System.out.println("Login button has been clicked to login to the user's profile");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	//Function to Assert Review was displayed
	public void reviewDisplayed() {

		try{
			WebElement reviewed = wait.until(ExpectedConditions.visibilityOfElementLocated(myReview));
			Assert.assertTrue("My Review wasn't displayed",reviewed.isDisplayed());
			System.out.println("Review was successfully sent and displayed");
			/*if(reviewed.isDisplayed()){
				System.out.println("Review Confirmation screen is displayed");
			}
			else{
				System.out.println("Confirmation Screen didn't display");
			}*/

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}
}







