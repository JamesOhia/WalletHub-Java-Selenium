package pages;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import io.github.bonigarcia.wdm.WebDriverManager;

//Class Page used to Start the Browser
public class StartBrowser {
	private WebDriver driver = null;
		
	public StartBrowser(WebDriver driver) {
		
		this.driver  = driver;
	}

	//Here we initialize the browser chosen. Note that for Chrome the location popup is disabled so it is advisable to use chrome
	public WebDriver initializeBrowser() throws IOException {
		//Here we are making use of Config.properties to set the browser to use of your choice by just renaming it to the browser name specified below
			Properties config = new Properties(); 
			FileInputStream fis = new FileInputStream(System.getProperty("user.dir")+"\\src\\test\\java\\config\\config.properties");
			config.load(fis);
			String browserName = config.getProperty("browser");
			if (browserName.equals("chrome")){ //Use Chrome Browser
				//Instantiate the Chrome Options object that will enable the disabling of notification
				ChromeOptions options = new ChromeOptions();
				options.addArguments("--disable-notifications"); //Disable Location pop-up notification that has potential of displaying

				System.setProperty("webdriver.chrome.driver",System.getProperty("user.dir")+"\\drivers\\chromedriver\\chromedriver.exe");

				// Pass the ChromeOptions instance while creating the ChromeDriver
				this.driver = new ChromeDriver(options);
			}

			else if (browserName.equals("fireFox")) { //Use Firefox Browser
				System.setProperty("webdriver.gecko.driver",System.getProperty("user.dir")+"\\drivers\\geckodriver\\geckodriver.exe");
				this.driver = new FirefoxDriver();
			}

			else { //Use Internet Explorer Browser
				System.setProperty("webdriver.ie.driver",System.getProperty("user.dir")+"\\drivers\\IEDriver\\IEDriverServer.exe");	
				driver = new FirefoxDriver();
			}
						
			System.out.println("Browser Initialize. Test Passed");
			return driver;

		}
		

	}

