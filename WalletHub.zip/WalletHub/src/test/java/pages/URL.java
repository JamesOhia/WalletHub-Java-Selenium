package pages;

import org.openqa.selenium.WebDriver;

public class URL {
	private WebDriver driver = null;

	private String faceBookUrl = "https://www.facebook.com/"; //URL for Assignment1
	private String walletHubUrl = "https://wallethub.com/profile/13732055i"; //URL for Assignment2

	//return FacbookUrl
	String getFaceBookUrl() {
		// TODO Auto-generated method stub
		return faceBookUrl;
	}

	//return WalletHubUrl
	String getWalletHubUrl() {
		// TODO Auto-generated method stub
		return walletHubUrl;
	}
}
