package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;

//Class used to store Facebook WebElement and create respective click functions. Here we are making use of Page Object Model
//for Object Repository.
public class FacebookPageObject {

	//The Web Element variables are below with their respective locators for searching elements such as id, name and xpath
	private By emailField = By.id("email");
	private By passwordField = By.id("pass");
	private By loginButton = By.name("login");
	private By homeIcon = By.xpath("(//span[@class = 'x1n2onr6'])[1]");
	private By statusButton = By.xpath("//span[contains(text(), 'What')]");
	private By postPopUp = By.xpath("//span[contains(text(),'Create post')]");
	private By statusInput = By.xpath("//p[@class='xdj266r x11i5rnm xat24cr x1mh8g0r x16tdsg8']");
	private By postButton = By.xpath("//div[@aria-label='Post']");




	private WebDriver driver;
	private WebDriverWait wait;

	public FacebookPageObject(WebDriver driver) {
		this.driver = driver;
		wait = new WebDriverWait(this.driver, 15);//Explicit WebDriverWait setup
	}

	//Function to enter Username
	public void enterUsername(String text) {

		try{
			WebElement emailInput = wait.until(ExpectedConditions.visibilityOfElementLocated(emailField));
			emailInput.sendKeys(text);
			System.out.println("Username was entered into the text field");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	//Function to enter password
	public void enterPassword(String text) {

		try{
			driver.findElement(passwordField).sendKeys(text);

			System.out.println("Password was entered into the text field");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	//function to click on the Login Button to login to facebook
	public void clickLoginButton() {

		try{
			driver.findElement(loginButton).click();

			System.out.println("Login Button was clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	//function to Assert that User has logged in
	public void loggedIn() {

		try{
			WebElement userLogged = wait.until(ExpectedConditions.visibilityOfElementLocated(homeIcon));
			userLogged.isDisplayed();
			if(userLogged.isDisplayed()){
				System.out.println("Successfully Logged into Facebook");
			}
			else{
				System.out.println("Unable to Login into Facebook");
			}
		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	//function to click on the Home Button of facebook just incase you are not in Home
	public void clickHomePage() {

		try{
			driver.findElement(homeIcon).click();

			System.out.println("Home Icon was clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	//function to click on the Status text Area
	public void clickStatusButton() {

		try{
			driver.findElement(statusButton).click();
			System.out.println("The Home Status Text Area was clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	//function to assert that the Create Post Popup was displayed
	public void postPopUpDisplayed() {

		try{
			WebElement popUp = wait.until(ExpectedConditions.visibilityOfElementLocated(postPopUp));
			if(popUp.isDisplayed()) {
				System.out.println("The Create a Post Pop up was displayed ");
			}
			else{
				System.out.println("The Pop up wasn't displayed ");
			}


		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	//function to enter Status to post
	public void enterStatus(String text) {

		try{
			driver.findElement(statusInput).sendKeys(text);
			System.out.println("Status to Post was entered into the text field");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	//function to click on the Post Status Button
	public void clickPost() {

		try{
			driver.findElement(postButton).click();
			System.out.println("Post Status Button was clicked");

		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

}







